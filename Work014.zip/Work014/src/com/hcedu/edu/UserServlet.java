package com.hcedu.edu;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.heedu.javabean.User;
import com.hcedu.service.UserService;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flag = request.getParameter("flag");
		UserService us = new UserService();
		if("queryAll".equals(flag)){
			List<User> list = us.queryAllUser();
			request.setAttribute("list", list);
			request.getRequestDispatcher("sys/User/index.jsp").forward(request, response);
		}else if("del".equals(flag)){
			int id = Integer.parseInt(request.getParameter("id"));
			int rows = us.delById(id);
			List<User> list = us.queryAllUser();
			request.setAttribute("list", list);
			request.getRequestDispatcher("sys/User/index.jsp").forward(request, response);
		}else if("queryById".equals(flag)){
			int userId = Integer.parseInt(request.getParameter("id"));
			User user = us.queryUserById(userId);
			request.setAttribute("user", user);
			request.getRequestDispatcher("sys/User/edit.jsp").forward(request, response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String flag = request.getParameter("flag");
		UserService us = new UserService();
		if("queryByName".equals(flag)){
			String userName = request.getParameter("username");
			List<User> list = us.queryUserByName(userName);
			request.setAttribute("list", list);
			request.getRequestDispatcher("sys/User/index.jsp").forward(request, response);
		}else if("edit".equals(flag)){
			User user = new User();
			int userId = Integer.parseInt(request.getParameter("id"));
			String userName = request.getParameter("username");
			String password = request.getParameter("password");
			String mail = request.getParameter("email");
			user.setUserId(userId);
			user.setUserName(userName);
			user.setPassword(password);
			user.setMail(mail);
			int rows = us.updateUserById(user);
			List<User> list = us.queryAllUser();
			request.setAttribute("list", list);
			request.getRequestDispatcher("sys/User/index.jsp").forward(request, response);		
		}else if("add".equals(flag)){
			User user = new User();
			String userName = request.getParameter("username");
			String password = request.getParameter("password");
			String mail = request.getParameter("email");
			user.setUserName(userName);
			user.setPassword(password);
			user.setMail(mail);
			int rows = us.insertUser(user);
			List<User> list = us.queryAllUser();
			request.setAttribute("list", list);
			request.getRequestDispatcher("sys/User/index.jsp").forward(request, response);
		}
		
	}

}
