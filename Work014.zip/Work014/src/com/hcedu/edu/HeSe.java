package com.hcedu.edu;
import java.io.IOException;
import java.io.PrintStream;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jasper.tagplugins.jstl.core.Out;

import com.hcedu.service.LoginServise;
import com.heedu.javabean.User;
public class HeSe extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public HeSe() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("������������doGet");
	}

		/*request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		String name = request.getParameter("username");
		String password = request.getParameter("password");
		LoginServise ls = new LoginServise();
		User user = ls.login(name, password);
		if(user.getUserName()!=null){*/
			/* out.print("<script language='javaScript'> alert('用户名不存在);</script>");
	         response.setHeader("refresh", "0;url=login.jsp");
			//
			
			request.setAttribute("userName", user.getUserName());
			request.getRequestDispatcher("sys/index.jsp")
				.forward(request, response);*/
		/*}else if(user.getPassword().equals(password)){
        
            out.print("<script language='javaScript'> alert('登录成功');</script>");
            response.setHeader("refresh", "0;url=Succes.jsp");
         }else {
        	 out.print("<script language='javaScript'> alert('密码错误');</script>");
             response.setHeader("refresh", "0;url=login.jsp");
			*/
		
			
		
		/*else{
			System.out.println(user.getUserName());
			System.out.println(user.getPassword());
		}*/
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			String name = request.getParameter("username");
			String password = request.getParameter("password");
			LoginServise ls = new LoginServise();
			User user = ls.login(name, password);
			if(user.getUserName()!=null){
				//跳转有两种方式：1、请求转发，2、重定向
				request.setAttribute("userName", user.getUserName());
				request.getRequestDispatcher("sys/index.jsp").forward(request, response);
				//request.getRequestDispatcher("sys/index.jsp").forward(request, response);	
				
			}else{
				//重定向，回到登录页面
				response.sendRedirect("sys/Manngerlogin.jsp");
			}
		}

	}



