package com.hcedu.service;

import com.hcedu.dao.LoginDao;
import com.heedu.javabean.User;

public class LoginServise {
	//��¼�ķ���
	public User login(String userName,String password){
		LoginDao ld = new LoginDao();
		return ld.Login(userName, password);
	}
}
