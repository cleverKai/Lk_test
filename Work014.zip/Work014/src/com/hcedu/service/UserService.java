package com.hcedu.service;
import java.rmi.server.UID;
import java.util.List;

import com.hcedu.dao.UserDao;
import com.heedu.javabean.User;

public class UserService {
	UserDao ud = new UserDao();
	public List<User> queryAllUser(){
		//UserDao ud = new UserDao();
		return ud.queryAllUser();
	}
     //删除Id用户
	public int delById(int  userId) {
		// TODO Auto-generated method stub
		return ud.delById(userId);
	}
	public List<User> queryUserByName(String userName) {
		// TODO Auto-generated method stub
		return ud.queryUserByName(userName);
	}
	public User queryUserById(int userId) {
		// TODO Auto-generated method stub
		return ud.queryUserById(userId);
	}
	 public int updateUserById(User user){
		 
		 return ud.updateUserById(user);
	      
	 }
	public int insertUser(User user) {
		// TODO Auto-generated method stub
		return ud.insertUser(user);
	}
}
	//根据id修改用户信息
	
	
