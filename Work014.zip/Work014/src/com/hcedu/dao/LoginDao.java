package com.hcedu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.hcedu.util.JdbcUtil;
import com.heedu.javabean.User;

public class LoginDao {
	public User Login(String userName,String password){
		JdbcUtil ju = new JdbcUtil();
		User user = new User();
		Connection conn = ju.getConection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select * from users where "
					+ "user_name=? and user_pwd=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, userName);
			pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			while(rs.next()){
				//user.setUserId(rs.getInt("user_id"));
				user.setUserName(rs.getString("user_name"));
				//user.setMail(rs.getString("user_mail"));
				//user.setGender(rs.getString("user_gender"));
				user.setPassword(rs.getString("user_pwd"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return user;
	}
}
