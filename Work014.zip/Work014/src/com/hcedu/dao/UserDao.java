package com.hcedu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.heedu.javabean.User;
import com.hcedu.util.JdbcUtil;

public class UserDao {
	public List<User> queryAllUser(){
		List<User> list = new ArrayList<User>();
		JdbcUtil ju = new JdbcUtil();
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			conn = ju.getConection();
			stmt = conn.createStatement();
			String sql = "select * from users";
			rs = stmt.executeQuery(sql);
			while(rs.next()){
				User user = new User();
				user.setUserId(rs.getInt("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setMail(rs.getString("user_mail"));
				//user.setGender(rs.getString("user_gender"));
				user.setPassword(rs.getString("user_pwd"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public List<User> queryUserByName(String userName){
		List<User> list = new ArrayList<User>();
		JdbcUtil ju = new JdbcUtil();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = ju.getConection();
			String sql = "select * from users where user_name like ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+userName+"%");
			rs = pstmt.executeQuery();
			while(rs.next()){
				User user = new User();
				user.setUserId(rs.getInt("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setMail(rs.getString("user_mail"));
				//user.setGender(rs.getString("user_gender"));
				user.setPassword(rs.getString("user_pwd"));
				list.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	public int delById(int userId){
		int rows = 0;
		JdbcUtil ju = new JdbcUtil();
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = ju.getConection();
		String sql = "delete from users where user_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rows = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return rows;
	}
	
	public User queryUserById(int userId){
		User user = new User();
		JdbcUtil ju = new JdbcUtil();
		Connection conn = ju.getConection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "select * from users where user_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, userId);
			rs = pstmt.executeQuery();
			while(rs.next()){
				user.setUserId(rs.getInt("user_id"));
				user.setUserName(rs.getString("user_name"));
				user.setMail(rs.getString("user_mail"));
				//user.setGender(rs.getString("user_gender"));
				user.setPassword(rs.getString("user_pwd"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return user;
	}
	
	public int updateUserById(User user){
		int rows = 0;
		JdbcUtil ju = new JdbcUtil();
		Connection conn = null;
		PreparedStatement pstmt = null;
		conn = ju.getConection();
		String sql = "update users set user_name=?,user_mail=?,user_pwd=? where user_id=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getMail());
			pstmt.setString(3, user.getPassword());
			pstmt.setInt(4, user.getUserId());
			rows = pstmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return rows;
	}	
		public int insertUser(User user){
			int rows = 0;
			JdbcUtil ju = new JdbcUtil();
			Connection conn = null;
			PreparedStatement pstmt = null;
			conn = ju.getConection();
			String sql = "insert into users(user_name,user_pwd,user_mail) values(?,?,?)";
			try {
				pstmt = conn.prepareStatement(sql);
				pstmt.setString(1, user.getUserName());
				pstmt.setString(2, user.getPassword());
				pstmt.setString(3, user.getMail());
				rows = pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {
				try {
					pstmt.close();
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return rows;
		}	
}
		
